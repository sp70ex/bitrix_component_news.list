<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Display element date";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Display element title";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Display element preview picture";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Display element preview text";
?>